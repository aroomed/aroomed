import type { Metadata } from "next";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: {
    default: "DevLog — A Tech & Programming Blog",
    template: "%s | DevLog",
  },
  description: "Thoughts on software engineering, developer tools, and the craft of programming.",
  openGraph: {
    type: "website",
    locale: "en_US",
    siteName: "DevLog",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <Navbar />
        <main style={{ minHeight: "100vh" }}>{children}</main>
        <Footer />
      </body>
    </html>
  );
}
