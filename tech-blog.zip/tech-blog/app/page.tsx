import { getAllPosts } from "@/lib/posts";
import PostCard from "@/components/PostCard";
import styles from "./page.module.css";

export default function Home() {
  const posts = getAllPosts();

  return (
    <div className={styles.container}>
      {/* Hero */}
      <section className={styles.hero}>
        <div className={styles.heroLabel}>
          <span className={styles.dot} />
          <span>Dev Blog</span>
        </div>
        <h1 className={styles.heroTitle}>
          Where code meets<br />
          <em>clarity.</em>
        </h1>
        <p className={styles.heroSub}>
          Deep dives into software engineering, tools, and the thinking behind great code.
        </p>
      </section>

      {/* Posts */}
      <section className={styles.posts}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionLabel}>Latest Posts</span>
          <div className={styles.sectionLine} />
        </div>
        <div className={styles.grid}>
          {posts.map((post) => (
            <PostCard key={post.slug} post={post} />
          ))}
        </div>
      </section>
    </div>
  );
}
