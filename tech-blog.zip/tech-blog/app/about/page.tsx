import type { Metadata } from "next";
import styles from "./page.module.css";

export const metadata: Metadata = {
  title: "About",
  description: "About this blog and its author.",
};

export default function About() {
  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <span className={styles.label}>About</span>
        <h1 className={styles.title}>Hi, I&apos;m a developer<br /><em>who writes.</em></h1>
      </div>

      <div className={styles.body}>
        <p>
          DevLog is where I think out loud about software. I write about the tools I use,
          the patterns I encounter, and the problems I find genuinely interesting.
        </p>
        <p>
          The posts here tend to be practical — not tutorials for their own sake, but
          records of things I figured out or found worth sharing. I care about clean code,
          good DX, and writing that respects the reader&apos;s time.
        </p>
        <p>
          If something here was useful to you, I&apos;d love to hear about it.
        </p>

        <div className={styles.links}>
          <a href="https://github.com" className={styles.link} target="_blank" rel="noopener noreferrer">
            <span className={styles.linkIcon}>⌥</span> GitHub
          </a>
          <a href="https://twitter.com" className={styles.link} target="_blank" rel="noopener noreferrer">
            <span className={styles.linkIcon}>⌘</span> Twitter / X
          </a>
        </div>
      </div>
    </div>
  );
}
