---
title: "The Git Workflow That Actually Stuck"
date: "2024-04-18"
excerpt: "After trying trunk-based development, gitflow, and everything in between — here's the branching strategy that works for small teams."
tag: "Git"
---

I've worked on teams that used every branching strategy imaginable. Long-lived feature branches, strict gitflow with develop and release, trunk-based development with feature flags, and the informal chaos of everyone committing to main and hoping for the best.

Here's what I've landed on for small teams (2–8 engineers), and why it stuck.

## The core idea: short-lived branches off main

Every feature or fix gets its own branch. The branch lives for at most a few days — ideally hours. When it's ready, it goes into a PR, gets reviewed, and merges to `main`. `main` is always deployable.

That's it. No `develop` branch, no `release` branches, no hotfix branches.

## Why long-lived branches are painful

The longer a branch lives, the more it diverges from `main`. Merging back becomes archaeology. You're resolving conflicts between code that was written weeks apart by people who may no longer remember the context.

The emotional weight of a "big PR" also changes how reviewers behave. Nobody gives 400 lines of changes the same attention as 40. You end up rubber-stamping things you shouldn't.

## The workflow in practice

```bash
# Start work
git checkout main && git pull
git checkout -b feature/add-user-avatars

# Work in small commits
git commit -m "add avatar upload endpoint"
git commit -m "resize images on upload"
git commit -m "display avatar in profile header"

# Open PR, get review, merge
# Delete branch after merge
```

The small commits matter. They're not just for aesthetics — they make the PR easier to review, easier to revert if something goes wrong, and they force you to think in discrete units of work.

## Handling work that isn't done

The biggest objection is: what if the feature isn't ready to ship when you merge? Two options:

**Feature flags.** Merge the code behind a flag that's off by default. The code lives in `main` but users don't see it. When it's ready, flip the flag. This is how large teams ship continuously.

**Vertical slices.** Break the feature into pieces that are independently useful. "Add avatar upload" might ship before "display avatar everywhere" — that's fine. Users get partial value, you get continuous integration.

## What makes it work

Small PRs require trust and fast review turnaround. If PRs sit for two days waiting for feedback, people will stop opening them and go back to big batches. The social contract is: small PR → fast review (same day, ideally within hours).

It also requires that `main` is protected. Required CI, required approvals. If `main` can break silently, the whole thing falls apart.

Once the habit is established, the feedback loop becomes addictive. Merge, deploy, done. Start the next thing. There's no purgatory of half-finished branches accumulating in the sidebar.
