---
title: "Why I Switched from useEffect to React Query"
date: "2024-06-10"
excerpt: "Data fetching in React is deceptively tricky. Here's what changed when I stopped rolling my own and let a library handle the hard parts."
tag: "React"
---

For the first two years of my React career, every data-fetching pattern I wrote looked roughly the same: a `useEffect` with a `useState` for data, loading, and error. It worked. It was also, in hindsight, quietly broken in a dozen subtle ways.

## The illusion of control

The pattern feels good because you understand every line:

```javascript
function UserProfile({ userId }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/users/${userId}`)
      .then(res => res.json())
      .then(data => {
        setUser(data);
        setLoading(false);
      });
  }, [userId]);

  if (loading) return <Spinner />;
  return <div>{user.name}</div>;
}
```

Readable. Simple. But it has a race condition: if `userId` changes before the first fetch resolves, you'll set state from the wrong response. It has no caching: every mount fires a fresh request. It has no deduplication: two components asking for the same user make two requests.

## What React Query actually gives you

React Query's value isn't that it fetches data. It's that it manages the *lifecycle* of server state — something your component simply shouldn't have to do.

```javascript
function UserProfile({ userId }) {
  const { data: user, isLoading } = useQuery({
    queryKey: ['user', userId],
    queryFn: () => fetch(`/api/users/${userId}`).then(r => r.json()),
  });

  if (isLoading) return <Spinner />;
  return <div>{user.name}</div>;
}
```

The API is nearly identical but the behavior is completely different. Requests are deduplicated. Results are cached by key. Data stays fresh in the background. Race conditions are handled automatically.

## The mental model shift

The most useful reframing for me was this: **`useEffect` is for synchronizing with external systems. It's not for fetching data.**

Fetching data is a separate concern that has its own set of requirements — caching, background refresh, optimistic updates, error retry. A library that focuses on that problem will do it better than anything you bolt onto `useEffect`.

I'm not saying `useEffect` is bad. It's exactly the right tool when you actually need to synchronize with a DOM event, a WebSocket, or a third-party library. It's just the wrong tool for the job we kept using it for.

## Worth the dependency?

For a small project where you hit one or two endpoints, probably not. But the moment you have multiple components that share data, or you care about your app feeling responsive on a slow connection, React Query earns its bundle size quickly.

The measure I use: if I've written `const [loading, setLoading] = useState(true)` more than twice in the same codebase, I should already have React Query installed.
