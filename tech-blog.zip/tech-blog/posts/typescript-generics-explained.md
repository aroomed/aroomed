---
title: "TypeScript Generics Without the Headache"
date: "2024-05-22"
excerpt: "Generics intimidated me for months. Once I understood what problem they actually solve, everything clicked."
tag: "TypeScript"
---

Generics were the part of TypeScript I avoided the longest. The syntax looked intimidating, the error messages were cryptic, and I could usually get by without them. Then I spent an afternoon really understanding what they do, and I've never looked back.

## The problem they solve

Without generics, you face a choice: be specific and duplicate code, or be flexible and lose type safety.

Say you want a function that returns the first element of an array. Without generics:

```typescript
// Option 1: Specific but duplicated
function firstString(arr: string[]): string { return arr[0]; }
function firstNumber(arr: number[]): number { return arr[0]; }

// Option 2: Flexible but unsafe
function first(arr: any[]): any { return arr[0]; }
```

Option 2 works at runtime but you've thrown away everything TypeScript gives you. The return type is `any`, so the compiler can't help you downstream.

## The generic solution

```typescript
function first<T>(arr: T[]): T {
  return arr[0];
}

const name = first(["Alice", "Bob"]); // string
const score = first([98, 72, 85]);     // number
```

`T` is a placeholder. When you call `first(["Alice", "Bob"])`, TypeScript infers `T = string` and knows the return type is also `string`. No duplicated functions, no `any`.

## A more practical example

Here's a pattern I reach for constantly — a typed API fetcher:

```typescript
async function fetchJson<T>(url: string): Promise<T> {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json() as Promise<T>;
}

interface User {
  id: number;
  name: string;
  email: string;
}

const user = await fetchJson<User>("/api/user/1");
// user.name is typed as string ✓
// user.missing would be a compile error ✓
```

## Constraints

Sometimes you need `T` to have certain properties. That's what `extends` is for:

```typescript
function getKey<T extends { id: number }>(item: T): number {
  return item.id;
}
```

Now TypeScript knows `T` will always have `id: number`, so `item.id` is safe to access. You can still pass any object that has that field.

## When to reach for generics

The signal for me is repetition with types swapped out, or when I catch myself writing `: any` and feeling vaguely guilty. Those are the moments where a generic would preserve flexibility without sacrificing correctness.

Don't over-generic everything. A function that only ever takes a `User` should just take a `User`. Generics solve a specific problem — don't reach for them when you don't have it.
