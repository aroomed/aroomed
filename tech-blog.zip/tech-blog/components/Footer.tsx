import styles from "./Footer.module.css";

export default function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={styles.inner}>
        <span className={styles.copy}>
          © {new Date().getFullYear()} DevLog
        </span>
        <span className={styles.built}>
          Built with Next.js · Deployed on Vercel
        </span>
      </div>
    </footer>
  );
}
