import Link from "next/link";
import { format } from "date-fns";
import { Post } from "@/lib/posts";
import styles from "./PostCard.module.css";

interface Props {
  post: Post;
}

export default function PostCard({ post }: Props) {
  return (
    <Link href={`/blog/${post.slug}`} className={styles.card}>
      <div className={styles.main}>
        <div className={styles.meta}>
          <span className={styles.tag}>{post.tag}</span>
          <span className={styles.date}>
            {format(new Date(post.date), "MMM d, yyyy")}
          </span>
        </div>
        <h2 className={styles.title}>{post.title}</h2>
        <p className={styles.excerpt}>{post.excerpt}</p>
      </div>
      <div className={styles.arrow}>→</div>
    </Link>
  );
}
