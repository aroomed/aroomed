# DevLog — Next.js Tech Blog

A clean, dark-mode tech blog built with **Next.js 14** and **TypeScript**, ready to deploy on **Vercel**.

## Getting Started in Cursor

1. Open this folder in Cursor
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the dev server:
   ```bash
   npm run dev
   ```
4. Visit [http://localhost:3000](http://localhost:3000)

## Writing Posts

Add Markdown files to the `/posts` directory. Each file needs frontmatter:

```md
---
title: "Your Post Title"
date: "2024-06-15"
excerpt: "A short description shown on the home page."
tag: "React"
---

Your content here...
```

The blog automatically picks up all `.md` files in `/posts` and sorts them by date.

## Deploying to Vercel

### Option 1: Vercel CLI
```bash
npx vercel
```
Follow the prompts — Vercel auto-detects Next.js.

### Option 2: GitHub + Vercel Dashboard
1. Push this project to a GitHub repo
2. Go to [vercel.com](https://vercel.com) → New Project
3. Import your GitHub repo
4. Click Deploy — no config needed

## Project Structure

```
tech-blog/
├── app/                  # Next.js App Router
│   ├── layout.tsx        # Root layout (Navbar, Footer)
│   ├── page.tsx          # Home page
│   ├── about/            # About page
│   └── blog/[slug]/      # Individual post pages
├── components/           # Reusable components
│   ├── Navbar.tsx
│   ├── PostCard.tsx
│   └── Footer.tsx
├── lib/
│   └── posts.ts          # Markdown reading utilities
├── posts/                # Your blog posts (.md files)
└── vercel.json           # Vercel deployment config
```

## Customizing

- **Site name & description** — edit `app/layout.tsx` metadata
- **Colors & fonts** — edit `app/globals.css` CSS variables
- **Nav links** — edit `components/Navbar.tsx`
- **About page** — edit `app/about/page.tsx`
